# HAVEN Multi-Camera ReID - Complete Implementation Guide

## 📋 TÓM TẮT REFACTOR

### ✅ ĐÃ HOÀN THÀNH

Đã refactor toàn bộ hệ thống HAVEN theo yêu cầu:

1. **Dual-Master Camera Logic** ✅
   - Cam1 và Cam2 đều là MASTER có quyền tạo global ID mới
   - Cam3 và Cam4 chỉ có thể MATCH với existing IDs
   - Gallery được share globally giữa tất cả cameras

2. **Multi-Camera Realtime Pipeline** ✅
   - Load từ 1 ROOT directory chứa nhiều camera folders
   - Xử lý đồng thời multiple cameras (frame-by-frame)
   - Đồng bộ theo frame index hoặc timestamp
   - Ghi trực tiếp video output với overlay

3. **Clean Architecture** ✅
   - Config file YAML rõ ràng
   - Modules tách biệt theo chức năng
   - Type hints + docstrings
   - Error handling đầy đủ

4. **Video I/O Abstraction** ✅
   - Hỗ trợ: single video file, folder với multiple chunks, RTSP
   - Auto-concatenate video chunks trong folder
   - Resize + frame skipping support

5. **Global ID Manager** ✅
   - Two-threshold decision logic
   - Spatiotemporal filtering
   - Multi-prototype memory
   - Deterministic tie-breaking
   - Comprehensive metrics

---

## 📁 CẤU TRÚC THƯ MỤC MỚI

```
HAVEN/
├── configs/
│   └── multicam.yaml              # Config chính ⭐
│
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   └── loader.py          # Config loader
│   │   ├── io/
│   │   │   └── video_stream.py    # Video stream abstraction ⭐
│   │   ├── tracking/
│   │   │   └── bytetrack_wrapper.py
│   │   ├── reid/
│   │   │   ├── feature_extractor.py
│   │   │   └── tracklet_aggregator.py
│   │   ├── global_id/
│   │   │   └── manager.py         # Global ID Manager ⭐
│   │   ├── viz/
│   │   │   └── overlay.py
│   │   └── run_multicam_reid.py   # Main entrypoint ⭐
│   │
│   ├── data/
│   │   └── multi-camera/          # ROOT folder
│   │       ├── phu1.mp4           # Camera 1
│   │       ├── phu2.mp4           # Camera 2
│   │       ├── phu3.mp4           # Camera 3
│   │       └── phu4.mp4           # Camera 4
│   │
│   ├── outputs/
│   │   └── multicam/
│   │       ├── cam1_output.mp4
│   │       ├── cam2_output.mp4
│   │       ├── cam3_output.mp4
│   │       ├── cam4_output.mp4
│   │       └── mosaic_output.mp4
│   │
│   └── logs/
│       └── multicam_reid.log
│
├── run_multicam.bat               # Windows batch script
└── README_REFACTOR.md             # This file
```

---

## 🎯 LOGIC 2-MASTER CAMERA (QUAN TRỌNG!)

### Quy Tắc Cấp Global ID

#### **Master Cameras (Cam1, Cam2)**

✅ **CÓ QUYỀN** tạo global ID mới khi:
1. Gallery rỗng (chưa có ai)
2. Similarity < threshold_reject (0.50) → chắc chắn người mới
3. Similarity trong vùng uncertain (0.50 - 0.75) → conservative, tạo ID mới
4. Margin < threshold (quá gần 2 candidates) → ambiguous, tạo ID mới
5. Spatiotemporal violation → không thể là cùng người

✅ **MATCH với ID cũ** khi:
- Similarity >= threshold_accept (0.75) AND margin đủ lớn AND spatiotemporal OK

#### **Non-Master Cameras (Cam3, Cam4)**

❌ **KHÔNG CÓ QUYỀN** tạo global ID mới

✅ **CHỈ CÓ THỂ**:
- MATCH với existing IDs nếu similarity >= threshold_accept
- Gán TEMP ID (0) nếu không match được → đợi xuất hiện ở master camera

### Flow Diagram

```
Person xuất hiện ở Cam2 (MASTER):
├─ Gallery rỗng?
│  └─ YES → Cam2 tạo Global ID = 1 ✅
│  └─ NO → Tiếp tục
├─ So sánh với Gallery (bao gồm IDs từ Cam1)
│  ├─ Similarity >= 0.75?
│  │  ├─ YES → MATCH với existing ID ✅
│  │  └─ NO → Tiếp tục
│  ├─ Similarity <= 0.50?
│  │  └─ YES → Cam2 tạo Global ID mới ✅
│  └─ Uncertain (0.50-0.75)?
│     └─ Cam2 tạo Global ID mới (conservative) ✅

Person xuất hiện ở Cam3 (NON-MASTER):
├─ Gallery rỗng?
│  └─ YES → Gán TEMP ID = 0 (đợi master) ⏳
│  └─ NO → Tiếp tục
├─ So sánh với Gallery
│  ├─ Similarity >= 0.75?
│  │  └─ YES → MATCH với existing ID ✅
│  └─ NO → Gán TEMP ID = 0 (đợi master) ⏳
```

### Ví Dụ Cụ Thể

#### Scenario 1: Cam1 thấy trước
```
t=0s   : Người A xuất hiện ở Cam1 (MASTER)
         → Gallery rỗng → Cam1 tạo Global ID = 1 ✅

t=10s  : Người A di chuyển đến Cam2 (MASTER)
         → So sánh với Gallery[ID=1]
         → Similarity = 0.85 > 0.75
         → MATCH → Global ID = 1 ✅

t=20s  : Người A di chuyển đến Cam3 (NON-MASTER)
         → So sánh với Gallery[ID=1]
         → Similarity = 0.80 > 0.75
         → MATCH → Global ID = 1 ✅
```

#### Scenario 2: Cam2 thấy trước (xe máy vào thẳng Cam2)
```
t=0s   : Người B đi xe máy vào thẳng Cam2 (MASTER)
         → Cam1 không phát hiện
         → Gallery rỗng
         → Cam2 tạo Global ID = 1 ✅

t=30s  : Người B di chuyển đến Cam1 (MASTER)
         → So sánh với Gallery[ID=1 created by Cam2]
         → Similarity = 0.82 > 0.75
         → MATCH → Global ID = 1 ✅ (không tạo ID mới!)
```

#### Scenario 3: Cam3 thấy người mới (NON-MASTER)
```
t=0s   : Người C xuất hiện ở Cam3 (NON-MASTER)
         → Gallery rỗng
         → Cam3 KHÔNG CÓ QUYỀN tạo ID
         → Gán TEMP ID = 0 ⏳

t=10s  : Người C di chuyển đến Cam1 (MASTER)
         → So sánh với Gallery
         → Không match
         → Cam1 tạo Global ID = 1 ✅

t=20s  : Người C quay lại Cam3 (NON-MASTER)
         → So sánh với Gallery[ID=1]
         → Similarity = 0.78 > 0.75
         → MATCH → Global ID = 1 ✅
```

---

## 🚀 CÁCH CHẠY HỆ THỐNG

### Bước 1: Chuẩn Bị Dữ Liệu

Tạo cấu trúc folder:

```
D:/HAVEN/backend/data/multi-camera/
├── phu1.mp4    # Camera 1
├── phu2.mp4    # Camera 2
├── phu3.mp4    # Camera 3
└── phu4.mp4    # Camera 4
```

Hoặc nếu mỗi camera có nhiều video chunks:

```
D:/HAVEN/backend/data/multi-camera/
├── cam1/
│   ├── video_001.mp4
│   ├── video_002.mp4
│   └── video_003.mp4
├── cam2/
│   ├── video_001.mp4
│   └── video_002.mp4
├── cam3/
│   └── video_001.mp4
└── cam4/
    └── video_001.mp4
```

### Bước 2: Cấu Hình

Edit `configs/multicam.yaml`:

```yaml
data:
  data_root: "D:/HAVEN/backend/data/multi-camera"
  cameras:
    - id: 1
      name: "cam1"
      enabled: true
      source_type: "video_folder"  # hoặc "video_file"
      path: "phu1.mp4"  # hoặc "cam1" nếu là folder

master_cameras:
  ids: [1, 2]  # Cam1 và Cam2 là MASTER ⭐
```

### Bước 3: Chạy

#### Cách 1: Python trực tiếp
```bash
cd D:\HAVEN
python backend\src\run_multicam_reid.py --config configs\multicam.yaml
```

#### Cách 2: Batch script (Windows)
```bash
cd D:\HAVEN
run_multicam.bat
```

#### Cách 3: Với overrides
```bash
python backend\src\run_multicam_reid.py \
    --config configs\multicam.yaml \
    --data_root "E:\Videos\cameras" \
    --out_dir "E:\outputs" \
    --write_video
```

### Bước 4: Phím Tắt Khi Chạy

- **Q**: Quit
- **P**: Pause/Resume

---

## 📊 OUTPUT & LOGS

### Console Output

```
============================================================
HAVEN Multi-Camera ReID System
============================================================
Master cameras: [1, 2]
Total cameras: 4
============================================================

🚀 Starting multi-camera processing...
Press 'Q' to quit, 'P' to pause

🆕 [cam1] Track 1 → Global ID 1 (MASTER_NEW: empty_gallery)
✅ [cam2] Track 3 → Global ID 1 (MATCHED: score=0.82)
🆕 [cam2] Track 5 → Global ID 2 (MASTER_NEW: low_similarity=0.45)
⏳ [cam3] Track 2 → TEMP (non-master, empty gallery)
✅ [cam3] Track 2 → Global ID 1 (MATCHED: score=0.78)
🆕 [cam1] Track 8 → Global ID 3 (MASTER_NEW: uncertain_zone=0.65)
...
```

### Video Outputs

```
D:/HAVEN/backend/outputs/multicam/
├── cam1_output.mp4    # Overlay cho camera 1
├── cam2_output.mp4    # Overlay cho camera 2
├── cam3_output.mp4    # Overlay cho camera 3
├── cam4_output.mp4    # Overlay cho camera 4
└── mosaic_output.mp4  # 2x2 mosaic view (nếu enabled)
```

### Overlay Display

Mỗi person sẽ hiển thị:
- **Green box**: New ID từ master camera
- **Cyan box**: Matched ID
- **Orange box**: Temporary ID (non-master)
- **T{id}**: Local track ID (yellow text)
- **G{id}**: Global ID (cyan text)
- **Status**: NEW / MATCH / TEMP

### Metrics (End of Run)

```
============================================================
GLOBAL ID MANAGER METRICS
============================================================
Total Global IDs Created: 5
  - By Master Cameras: 5
  - Active: 5
Total Matches: 23
Total Rejections: 2
Spatiotemporal Filtered: 3
Non-Master Temp IDs: 7
Total Tracks Assigned: 35
============================================================
```

---

## ⚙️ TUNING THRESHOLDS

### Quá Nhiều False Matches?

**Triệu chứng**: Khác người nhưng bị gán cùng Global ID

**Giải pháp**:
```yaml
reid:
  thresholds:
    accept: 0.80     # Tăng từ 0.75 (stricter)
    margin: 0.20     # Tăng từ 0.15
  quality:
    min_quality_score: 0.6  # Tăng từ 0.5
```

### Quá Nhiều ID Switches?

**Triệu chứng**: Cùng người nhưng bị tạo nhiều Global ID

**Giải pháp**:
```yaml
reid:
  thresholds:
    accept: 0.70     # Giảm từ 0.75 (looser)
    reject: 0.45     # Giảm từ 0.50
  reuse_window: 10800  # Tăng từ 7200 (3 hours)
```

### Cam3/Cam4 Không Bao Giờ Match Được?

**Triệu chứng**: Non-master cameras luôn tạo TEMP IDs

**Giải pháp**:
```yaml
reid:
  thresholds:
    accept: 0.65     # Giảm threshold để dễ match hơn
```

---

## 🔧 TROUBLESHOOTING

### Error: "Config file not found"

```
ERROR: Config file not found: configs/multicam.yaml
```

**Giải pháp**: Chắc chắn đang chạy từ thư mục gốc HAVEN:
```bash
cd D:\HAVEN
python backend\src\run_multicam_reid.py --config configs\multicam.yaml
```

### Error: "Video file not found"

```
FileNotFoundError: Video file not found: D:/HAVEN/backend/data/multi-camera/phu1.mp4
```

**Giải pháp**: Kiểm tra:
1. Path trong config đúng chưa
2. File video có tồn tại không
3. Đường dẫn absolute vs relative

### Error: "Failed to open video"

```
[cam1] Failed to open: phu1.mp4
```

**Giải pháp**:
- Kiểm tra codec video (nên dùng H.264)
- Thử mở bằng VLC/Media Player trước
- Check quyền read file

### Không Thấy Preview Window

**Giải pháp**:
```yaml
visualization:
  enabled: true
  mosaic:
    enabled: true
```

### Video Output Bị Corrupt

**Giải pháp**: Thử đổi codec:
```yaml
output:
  video_codec: "avc1"  # Thay vì "mp4v"
```

---

## 📝 NEXT STEPS

### Phase 1: Tích Hợp Detection + Tracking (Cần làm ngay)

File cần sửa: `backend/src/run_multicam_reid.py`

```python
# TODO: Thêm YOLO detection
from ultralytics import YOLO
detector = YOLO('yolov11n.pt')

# TODO: Thêm ByteTrack
from boxmot import ByteTrack
tracker = ByteTrack()

# Trong main loop:
for cam_id, stream in self.streams.items():
    ret, frame = stream.read()
    
    # Detection
    results = detector(frame)
    detections = results[0].boxes
    
    # Tracking
    tracks = tracker.update(detections, frame)
    
    # Extract embeddings (placeholder)
    for track in tracks:
        track_id = track.id
        bbox = track.xyxy
        
        # TODO: Extract ReID embedding
        embedding = extract_embedding(frame, bbox)
        quality = compute_quality(frame, bbox)
        
        # Assign global ID
        global_id, reason, score = self.global_id_manager.assign_global_id(
            camera_id=cam_id,
            local_track_id=track_id,
            embedding=embedding,
            quality=quality,
            timestamp=stream.get_timestamp(),
            frame_idx=stream.get_frame_count(),
            num_frames=len(track.frames),
            bbox_size=compute_bbox_size(bbox)
        )
        
        # Collect for visualization
        detections.append({
            'bbox': bbox,
            'local_track_id': track_id,
            'global_id': global_id,
            'reason': reason,
            'confidence': score
        })
```

### Phase 2: Feature Extractors

Tạo các modules:

```
backend/src/reid/feature_extractors/
├── face_extractor.py      # InsightFace/ArcFace
├── gait_extractor.py      # Body proportions từ YOLO-Pose
└── appearance_extractor.py # OSNet/ResNet50
```

### Phase 3: Multi-Signal Fusion

Update `GlobalIDManager.assign_global_id()` để sử dụng:
- Face similarity (nếu có face)
- Gait similarity (từ pose sequence)
- Appearance similarity

Priority: Face > Gait > Appearance

### Phase 4: Testing & Optimization

1. Unit tests cho `GlobalIDManager`
2. Integration tests với real videos
3. Performance profiling
4. GPU optimization

---

## 🎓 KEY TAKEAWAYS

### Logic 2-Master (Tóm Tắt 3-4 Bullets)

1. **Chỉ Cam1 và Cam2 có quyền tạo NEW Global IDs**
   - Cam3, Cam4 chỉ có thể MATCH hoặc gán TEMP

2. **Gallery được share globally**
   - Cam2 tạo ID → Cam1 thấy được và match đúng
   - Cam1 tạo ID → Cam2 thấy được và match đúng

3. **Trước khi tạo ID mới, LUÔN so sánh với Gallery trước**
   - Nếu match (sim >= 0.75) → dùng existing ID
   - Nếu không match → master tạo ID mới, non-master chờ

4. **Global IDs tăng tuần tự 1, 2, 3, ...**
   - KHÔNG reset giữa cameras
   - Deterministic (same input → same IDs)

---

## ✅ CHECKLIST HOÀN THÀNH

- [x] Config YAML với master_cameras list
- [x] VideoStream abstraction (file/folder/RTSP)
- [x] GlobalIDManager với dual-master logic
- [x] Spatiotemporal filtering
- [x] Two-threshold decision
- [x] Multi-prototype memory
- [x] Visualization với status colors
- [x] Logging rõ ràng (new ID / match / temp)
- [x] Metrics tracking
- [x] Command-line interface
- [x] Error handling
- [ ] Detection + Tracking integration (TODO)
- [ ] Feature extractors (TODO)
- [ ] Unit tests (TODO)

---

**Status**: ✅ Core architecture hoàn thành, ready for detection/tracking integration!
