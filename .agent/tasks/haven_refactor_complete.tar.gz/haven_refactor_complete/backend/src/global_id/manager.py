"""
Global Identity Manager với Dual-Master Camera Support

Quản lý global IDs across multiple cameras với logic:
- Chỉ master cameras (cam1, cam2) có quyền tạo NEW global IDs
- Non-master cameras chỉ có thể MATCH với existing IDs
- Gallery được share giữa tất cả cameras
- Spatiotemporal constraints để filter impossible transitions
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class TrackEmbedding:
    """Single embedding from a track"""
    embedding: np.ndarray
    quality: float
    timestamp: float
    camera_id: int
    frame_idx: int


@dataclass
class GlobalIdentity:
    """Global identity across cameras"""
    global_id: int
    embeddings: List[TrackEmbedding] = field(default_factory=list)
    first_seen: float = 0.0
    last_seen: float = 0.0
    cameras_seen: Set[int] = field(default_factory=set)
    created_by_camera: int = 0
    is_active: bool = True
    
    def add_embedding(self, embedding: TrackEmbedding, max_size: int = 10):
        """Add embedding with quality-based pruning"""
        self.embeddings.append(embedding)
        self.last_seen = embedding.timestamp
        self.cameras_seen.add(embedding.camera_id)
        
        # Keep only top-k by quality
        if len(self.embeddings) > max_size:
            self.embeddings.sort(key=lambda x: x.quality, reverse=True)
            self.embeddings = self.embeddings[:max_size]
    
    def get_best_embedding(self) -> Optional[np.ndarray]:
        """Get highest quality embedding"""
        if not self.embeddings:
            return None
        return max(self.embeddings, key=lambda x: x.quality).embedding
    
    def get_average_embedding(self) -> Optional[np.ndarray]:
        """Get quality-weighted average embedding"""
        if not self.embeddings:
            return None
        
        weights = np.array([e.quality for e in self.embeddings])
        weights = weights / weights.sum()
        
        embeddings = np.array([e.embedding for e in self.embeddings])
        avg_emb = np.average(embeddings, weights=weights, axis=0)
        
        # Normalize
        return avg_emb / (np.linalg.norm(avg_emb) + 1e-8)


class GlobalIDManager:
    """
    Manages global identity assignment across cameras with dual-master support.
    
    Key Features:
    - Only master cameras can create NEW global IDs
    - All cameras share the same gallery
    - Spatiotemporal filtering
    - Two-threshold decision logic
    - Deterministic tie-breaking
    """
    
    def __init__(
        self,
        master_camera_ids: List[int],
        camera_graph: Dict,
        threshold_accept: float = 0.75,
        threshold_reject: float = 0.50,
        margin_threshold: float = 0.15,
        min_tracklet_frames: int = 5,
        min_bbox_size: int = 80,
        conflict_resolution: str = "camera_id",
        ema_alpha: float = 0.3,
        max_prototypes: int = 10,
        reuse_window: float = 7200.0,
    ):
        """
        Initialize Global ID Manager.
        
        Args:
            master_camera_ids: List of camera IDs that can create new IDs (e.g., [1, 2])
            camera_graph: Dict of transition times between cameras
            threshold_accept: Similarity >= this = confident match
            threshold_reject: Similarity <= this = definitely new person
            margin_threshold: Required margin between 1st and 2nd candidate
            min_tracklet_frames: Minimum frames per tracklet
            min_bbox_size: Minimum bbox size
            conflict_resolution: "camera_id" or "timestamp" for tie-breaking
            ema_alpha: EMA alpha for embedding update
            max_prototypes: Max embeddings per global ID
            reuse_window: Seconds before ID can be reused
        """
        self.master_camera_ids = set(master_camera_ids)
        self.camera_graph = camera_graph
        self.threshold_accept = threshold_accept
        self.threshold_reject = threshold_reject
        self.margin_threshold = margin_threshold
        self.min_tracklet_frames = min_tracklet_frames
        self.min_bbox_size = min_bbox_size
        self.conflict_resolution = conflict_resolution
        self.ema_alpha = ema_alpha
        self.max_prototypes = max_prototypes
        self.reuse_window = reuse_window
        
        # Global state
        self.next_global_id = 1
        self.gallery: Dict[int, GlobalIdentity] = {}  # global_id -> GlobalIdentity
        self.track_to_global: Dict[Tuple[int, int], int] = {}  # (cam_id, local_id) -> global_id
        
        # Metrics
        self.metrics = {
            'ids_created': 0,
            'ids_matched': 0,
            'ids_rejected': 0,
            'spatiotemporal_filtered': 0,
            'master_new_ids': 0,
            'non_master_temp_ids': 0,
        }
        
        logger.info(f"GlobalIDManager initialized:")
        logger.info(f"  Master cameras: {sorted(self.master_camera_ids)}")
        logger.info(f"  Thresholds: accept={threshold_accept}, reject={threshold_reject}, margin={margin_threshold}")
        logger.info(f"  Camera graph: {len(camera_graph)} cameras configured")
    
    def is_master_camera(self, camera_id: int) -> bool:
        """Check if camera is a master (can create new IDs)"""
        return camera_id in self.master_camera_ids
    
    def cosine_similarity(self, emb1: np.ndarray, emb2: np.ndarray) -> float:
        """Compute cosine similarity between two embeddings"""
        # Normalize
        emb1_norm = emb1 / (np.linalg.norm(emb1) + 1e-8)
        emb2_norm = emb2 / (np.linalg.norm(emb2) + 1e-8)
        
        # Dot product
        sim = np.dot(emb1_norm, emb2_norm)
        return float(sim)
    
    def compute_similarity_to_gallery(
        self,
        query_embedding: np.ndarray
    ) -> List[Tuple[int, float]]:
        """
        Compute similarities to all gallery identities.
        
        Returns:
            List of (global_id, similarity_score) sorted by score descending
        """
        if not self.gallery:
            return []
        
        similarities = []
        for global_id, identity in self.gallery.items():
            if not identity.is_active:
                continue
            
            # Get best prototype embedding for this identity
            proto_emb = identity.get_average_embedding()
            if proto_emb is None:
                continue
            
            sim = self.cosine_similarity(query_embedding, proto_emb)
            similarities.append((global_id, sim))
        
        # Sort by similarity descending
        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities
    
    def check_spatiotemporal_constraint(
        self,
        from_camera: int,
        to_camera: int,
        time_gap: float
    ) -> bool:
        """
        Check if transition is physically plausible.
        
        Args:
            from_camera: Previous camera ID
            to_camera: Current camera ID
            time_gap: Time difference in seconds
        
        Returns:
            True if plausible, False otherwise
        """
        # Same camera: always plausible if within reuse window
        if from_camera == to_camera:
            return time_gap < self.reuse_window
        
        # Different cameras: check graph
        if from_camera not in self.camera_graph:
            logger.warning(f"Camera {from_camera} not in graph")
            return True  # Allow if not configured
        
        transitions = self.camera_graph.get(from_camera, {})
        if to_camera not in transitions:
            logger.warning(f"No transition defined: cam{from_camera} -> cam{to_camera}")
            return True  # Allow if not configured
        
        constraint = transitions[to_camera]
        min_time = constraint['min_time']
        max_time = constraint['max_time']
        
        is_plausible = min_time <= time_gap <= max_time
        
        if not is_plausible:
            logger.debug(
                f"Spatiotemporal filter: cam{from_camera}->cam{to_camera} "
                f"time={time_gap:.1f}s (expected {min_time}-{max_time}s)"
            )
        
        return is_plausible
    
    def assign_global_id(
        self,
        camera_id: int,
        local_track_id: int,
        embedding: np.ndarray,
        quality: float,
        timestamp: float,
        frame_idx: int,
        num_frames: int,
        bbox_size: float,
        last_seen_info: Optional[Dict] = None
    ) -> Tuple[Optional[int], str, float]:
        """
        Assign global ID to a track.
        
        Args:
            camera_id: Camera ID
            local_track_id: Local track ID from ByteTrack
            embedding: ReID embedding vector
            quality: Quality score [0-1]
            timestamp: Timestamp in seconds
            frame_idx: Frame index
            num_frames: Number of frames in tracklet
            bbox_size: Bounding box size (pixels)
            last_seen_info: Optional info about where this person was last seen
        
        Returns:
            (global_id, reason, confidence_score)
            - global_id: Assigned global ID, 0 if temp/unassigned, None if rejected
            - reason: String explaining the decision
            - confidence_score: Similarity score if matched, 0 otherwise
        """
        track_key = (camera_id, local_track_id)
        
        # 1. Check if already assigned
        if track_key in self.track_to_global:
            existing_id = self.track_to_global[track_key]
            logger.debug(f"[cam{camera_id}] Track {local_track_id} already has global_id={existing_id}")
            return existing_id, "already_assigned", 1.0
        
        # 2. Quality gate
        if num_frames < self.min_tracklet_frames:
            logger.debug(f"[cam{camera_id}] Track {local_track_id} too short: {num_frames} frames")
            return None, "insufficient_frames", 0.0
        
        if bbox_size < self.min_bbox_size:
            logger.debug(f"[cam{camera_id}] Track {local_track_id} too small: {bbox_size}px")
            return None, "bbox_too_small", 0.0
        
        if quality < 0.3:  # Minimum quality threshold
            logger.debug(f"[cam{camera_id}] Track {local_track_id} low quality: {quality:.2f}")
            return None, "low_quality", 0.0
        
        # 3. Match against gallery
        similarities = self.compute_similarity_to_gallery(embedding)
        
        is_master = self.is_master_camera(camera_id)
        
        # 4. Decision logic
        if not similarities:
            # Empty gallery
            if is_master:
                # Master can create new ID
                global_id = self._create_new_global_id(
                    camera_id, local_track_id, embedding, quality, timestamp, frame_idx
                )
                self.metrics['ids_created'] += 1
                self.metrics['master_new_ids'] += 1
                logger.info(
                    f"🆕 [cam{camera_id}] Track {local_track_id} → Global ID {global_id} "
                    f"(MASTER_NEW: empty_gallery)"
                )
                return global_id, "new_identity_empty_gallery", 0.0
            else:
                # Non-master must wait
                logger.info(
                    f"⏳ [cam{camera_id}] Track {local_track_id} → TEMP (non-master, empty gallery)"
                )
                self.metrics['non_master_temp_ids'] += 1
                return 0, "wait_master_empty_gallery", 0.0
        
        # Get best match
        best_id, best_score = similarities[0]
        
        # 5. Two-threshold decision
        if best_score >= self.threshold_accept:
            # High confidence match
            
            # Check margin (ambiguity test)
            if len(similarities) > 1:
                second_score = similarities[1][1]
                margin = best_score - second_score
                
                if margin < self.margin_threshold:
                    # Too close, ambiguous
                    if is_master:
                        # Master can create new ID when ambiguous
                        global_id = self._create_new_global_id(
                            camera_id, local_track_id, embedding, quality, timestamp, frame_idx
                        )
                        self.metrics['ids_created'] += 1
                        self.metrics['master_new_ids'] += 1
                        logger.info(
                            f"🆕 [cam{camera_id}] Track {local_track_id} → Global ID {global_id} "
                            f"(MASTER_NEW: ambiguous margin={margin:.3f})"
                        )
                        return global_id, "new_identity_ambiguous", margin
                    else:
                        logger.info(
                            f"⏳ [cam{camera_id}] Track {local_track_id} → TEMP (ambiguous, non-master)"
                        )
                        self.metrics['non_master_temp_ids'] += 1
                        return 0, "wait_master_ambiguous", best_score
            
            # Spatiotemporal check
            if last_seen_info and best_id in self.gallery:
                identity = self.gallery[best_id]
                time_gap = timestamp - identity.last_seen
                
                # Find which camera this identity was last seen
                last_camera = identity.created_by_camera
                for cam_id in identity.cameras_seen:
                    # Get most recent camera (simplified)
                    last_camera = cam_id
                
                if not self.check_spatiotemporal_constraint(last_camera, camera_id, time_gap):
                    # Spatiotemporal violation
                    self.metrics['spatiotemporal_filtered'] += 1
                    
                    if is_master:
                        # Master creates new ID
                        global_id = self._create_new_global_id(
                            camera_id, local_track_id, embedding, quality, timestamp, frame_idx
                        )
                        self.metrics['ids_created'] += 1
                        self.metrics['master_new_ids'] += 1
                        logger.info(
                            f"🆕 [cam{camera_id}] Track {local_track_id} → Global ID {global_id} "
                            f"(MASTER_NEW: spatiotemporal_violation, score={best_score:.3f})"
                        )
                        return global_id, "new_identity_spatiotemporal", best_score
                    else:
                        logger.info(
                            f"⏳ [cam{camera_id}] Track {local_track_id} → TEMP (spatiotemporal, non-master)"
                        )
                        self.metrics['non_master_temp_ids'] += 1
                        return 0, "wait_master_spatiotemporal", best_score
            
            # All checks passed: confident match
            self._assign_to_existing_id(
                best_id, camera_id, local_track_id, embedding, quality, timestamp, frame_idx
            )
            self.metrics['ids_matched'] += 1
            logger.info(
                f"✅ [cam{camera_id}] Track {local_track_id} → Global ID {best_id} "
                f"(MATCHED: score={best_score:.3f})"
            )
            return best_id, "matched_confident", best_score
        
        elif best_score <= self.threshold_reject:
            # Low score: definitely new person
            if is_master:
                global_id = self._create_new_global_id(
                    camera_id, local_track_id, embedding, quality, timestamp, frame_idx
                )
                self.metrics['ids_created'] += 1
                self.metrics['master_new_ids'] += 1
                logger.info(
                    f"🆕 [cam{camera_id}] Track {local_track_id} → Global ID {global_id} "
                    f"(MASTER_NEW: low_similarity={best_score:.3f})"
                )
                return global_id, "new_identity_low_similarity", best_score
            else:
                # Non-master cannot create new ID
                logger.info(
                    f"⏳ [cam{camera_id}] Track {local_track_id} → TEMP (low_sim={best_score:.3f}, non-master)"
                )
                self.metrics['non_master_temp_ids'] += 1
                return 0, "wait_master_new_person", best_score
        
        else:
            # Uncertain zone [threshold_reject, threshold_accept]
            if is_master:
                # Master is conservative: create new ID in uncertain zone
                global_id = self._create_new_global_id(
                    camera_id, local_track_id, embedding, quality, timestamp, frame_idx
                )
                self.metrics['ids_created'] += 1
                self.metrics['master_new_ids'] += 1
                logger.info(
                    f"🆕 [cam{camera_id}] Track {local_track_id} → Global ID {global_id} "
                    f"(MASTER_NEW: uncertain_zone={best_score:.3f})"
                )
                return global_id, "new_identity_uncertain", best_score
            else:
                # Non-master waits
                logger.info(
                    f"⏳ [cam{camera_id}] Track {local_track_id} → TEMP (uncertain={best_score:.3f}, non-master)"
                )
                self.metrics['non_master_temp_ids'] += 1
                return 0, "wait_master_uncertain", best_score
    
    def _create_new_global_id(
        self,
        camera_id: int,
        local_track_id: int,
        embedding: np.ndarray,
        quality: float,
        timestamp: float,
        frame_idx: int
    ) -> int:
        """Create new global ID"""
        global_id = self.next_global_id
        self.next_global_id += 1
        
        # Create identity
        track_emb = TrackEmbedding(
            embedding=embedding,
            quality=quality,
            timestamp=timestamp,
            camera_id=camera_id,
            frame_idx=frame_idx
        )
        
        identity = GlobalIdentity(
            global_id=global_id,
            embeddings=[track_emb],
            first_seen=timestamp,
            last_seen=timestamp,
            cameras_seen={camera_id},
            created_by_camera=camera_id,
            is_active=True
        )
        
        self.gallery[global_id] = identity
        self.track_to_global[(camera_id, local_track_id)] = global_id
        
        return global_id
    
    def _assign_to_existing_id(
        self,
        global_id: int,
        camera_id: int,
        local_track_id: int,
        embedding: np.ndarray,
        quality: float,
        timestamp: float,
        frame_idx: int
    ):
        """Assign track to existing global ID"""
        track_key = (camera_id, local_track_id)
        self.track_to_global[track_key] = global_id
        
        # Update gallery
        if global_id in self.gallery:
            track_emb = TrackEmbedding(
                embedding=embedding,
                quality=quality,
                timestamp=timestamp,
                camera_id=camera_id,
                frame_idx=frame_idx
            )
            self.gallery[global_id].add_embedding(track_emb, self.max_prototypes)
    
    def get_global_id(self, camera_id: int, local_track_id: int) -> Optional[int]:
        """Get global ID for a track"""
        return self.track_to_global.get((camera_id, local_track_id))
    
    def get_metrics(self) -> Dict:
        """Get current metrics"""
        return {
            **self.metrics,
            'total_global_ids': len(self.gallery),
            'active_global_ids': sum(1 for id in self.gallery.values() if id.is_active),
            'total_tracks_assigned': len(self.track_to_global),
        }
    
    def print_metrics(self):
        """Print metrics summary"""
        metrics = self.get_metrics()
        logger.info("=" * 60)
        logger.info("GLOBAL ID MANAGER METRICS")
        logger.info("=" * 60)
        logger.info(f"Total Global IDs Created: {metrics['total_global_ids']}")
        logger.info(f"  - By Master Cameras: {metrics['master_new_ids']}")
        logger.info(f"  - Active: {metrics['active_global_ids']}")
        logger.info(f"Total Matches: {metrics['ids_matched']}")
        logger.info(f"Total Rejections: {metrics['ids_rejected']}")
        logger.info(f"Spatiotemporal Filtered: {metrics['spatiotemporal_filtered']}")
        logger.info(f"Non-Master Temp IDs: {metrics['non_master_temp_ids']}")
        logger.info(f"Total Tracks Assigned: {metrics['total_tracks_assigned']}")
        logger.info("=" * 60)
