"""
HAVEN Multi-Camera ReID System - Main Runner

Chức năng:
- Load config từ YAML
- Khởi tạo multiple camera streams
- Chạy detection + tracking per camera
- Assign global IDs với dual-master logic
- Visualize và ghi video output
"""

import sys
import os
import argparse
import yaml
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import cv2
import numpy as np
from datetime import datetime

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.io.video_stream import VideoStream
from src.global_id.manager import GlobalIDManager

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MultiCameraReIDSystem:
    """Multi-Camera Person Re-Identification System"""
    
    def __init__(self, config_path: str):
        """Initialize system with config file"""
        self.config = self._load_config(config_path)
        self.streams: Dict[int, VideoStream] = {}
        self.trackers: Dict[int, any] = {}  # Placeholder for ByteTrack
        self.global_id_manager: Optional[GlobalIDManager] = None
        self.video_writers: Dict[int, cv2.VideoWriter] = {}
        
        # Initialize components
        self._initialize_streams()
        self._initialize_global_id_manager()
        self._initialize_output()
    
    def _load_config(self, config_path: str) -> Dict:
        """Load YAML config"""
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        logger.info(f"✅ Loaded config from: {config_path}")
        return config
    
    def _initialize_streams(self):
        """Initialize video streams for all cameras"""
        data_root = self.config['data']['data_root']
        cameras = self.config['data']['cameras']
        
        logger.info(f"Initializing {len(cameras)} camera streams...")
        
        for cam_config in cameras:
            if not cam_config.get('enabled', True):
                logger.info(f"⏭️  Camera {cam_config['id']} disabled, skipping")
                continue
            
            try:
                stream = VideoStream(
                    camera_id=cam_config['id'],
                    camera_name=cam_config['name'],
                    source_type=cam_config['source_type'],
                    source_path=cam_config['path'],
                    data_root=data_root,
                    pattern=cam_config.get('pattern', '*.mp4'),
                    fps_override=cam_config.get('fps_override'),
                    resize_width=cam_config.get('resize_width', 640),
                    skip_frames=cam_config.get('skip_frames', 0)
                )
                
                self.streams[cam_config['id']] = stream
                logger.info(
                    f"✅ cam{cam_config['id']} ({cam_config['name']}): "
                    f"{cam_config['source_type']} - {cam_config['path']}"
                )
            
            except Exception as e:
                logger.error(f"❌ Failed to initialize cam{cam_config['id']}: {e}")
                raise
    
    def _initialize_global_id_manager(self):
        """Initialize global ID manager"""
        master_ids = self.config['master_cameras']['ids']
        camera_graph = self.config['camera_graph']['transitions']
        reid_config = self.config['reid']
        
        self.global_id_manager = GlobalIDManager(
            master_camera_ids=master_ids,
            camera_graph=camera_graph,
            threshold_accept=reid_config['thresholds']['accept'],
            threshold_reject=reid_config['thresholds']['reject'],
            margin_threshold=reid_config['thresholds']['margin'],
            min_tracklet_frames=reid_config['quality']['min_tracklet_frames'],
            min_bbox_size=reid_config['quality']['min_bbox_size'],
            conflict_resolution=self.config['master_cameras']['conflict_resolution'],
            ema_alpha=reid_config['ema_alpha'],
            max_prototypes=reid_config['multi_prototype']['memory_size'],
            reuse_window=reid_config['reuse_window']
        )
        
        logger.info("✅ Global ID Manager initialized")
    
    def _initialize_output(self):
        """Initialize output directories and video writers"""
        out_dir = self.config['output']['out_dir']
        os.makedirs(out_dir, exist_ok=True)
        
        # Create log directory
        log_file = self.config['output']['logging'].get('log_file')
        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        logger.info(f"✅ Output directory: {out_dir}")
    
    def _create_video_writer(self, camera_id: int, width: int, height: int, fps: float):
        """Create video writer for a camera"""
        if not self.config['output']['write_video']:
            return None
        
        out_dir = self.config['output']['out_dir']
        codec = self.config['output']['video_codec']
        output_fps = self.config['output']['video_fps']
        
        filename = f"cam{camera_id}_output.mp4"
        output_path = os.path.join(out_dir, filename)
        
        fourcc = cv2.VideoWriter_fourcc(*codec)
        writer = cv2.VideoWriter(output_path, fourcc, output_fps, (width, height))
        
        if not writer.isOpened():
            logger.error(f"Failed to create video writer: {output_path}")
            return None
        
        logger.info(f"📹 Writing output: {output_path}")
        return writer
    
    def _draw_overlay(
        self,
        frame: np.ndarray,
        detections: List[Dict],
        camera_id: int
    ) -> np.ndarray:
        """
        Draw overlay on frame.
        
        Args:
            frame: Input frame
            detections: List of detections with bbox, track_id, global_id, etc.
            camera_id: Camera ID
        
        Returns:
            Frame with overlay
        """
        vis_config = self.config['visualization']
        
        if not vis_config['enabled']:
            return frame
        
        overlay = frame.copy()
        colors = vis_config['colors']
        
        for det in detections:
            bbox = det['bbox']  # [x1, y1, x2, y2]
            local_id = det.get('local_track_id', -1)
            global_id = det.get('global_id', 0)
            reason = det.get('reason', '')
            confidence = det.get('confidence', 0.0)
            
            x1, y1, x2, y2 = map(int, bbox)
            
            # Choose color based on status
            if global_id > 0:
                if 'new_identity' in reason:
                    color = colors['new_id']
                    status = 'NEW'
                else:
                    color = colors['matched_id']
                    status = 'MATCH'
            elif global_id == 0:
                color = colors['wait_master']
                status = 'TEMP'
            else:
                color = colors['temp_id']
                status = 'REJECT'
            
            # Draw bbox
            if vis_config['show_bbox']:
                cv2.rectangle(overlay, (x1, y1), (x2, y2), color, 2)
            
            # Draw text
            y_offset = y1 - 10
            font_scale = vis_config['font_scale']
            thickness = vis_config['font_thickness']
            
            if vis_config['show_local_track_id']:
                text = f"T{local_id}"
                cv2.putText(overlay, text, (x1, y_offset), 
                           cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 0), thickness)
                y_offset -= 20
            
            if vis_config['show_global_id'] and global_id > 0:
                text = f"G{global_id}"
                cv2.putText(overlay, text, (x1, y_offset),
                           cv2.FONT_HERSHEY_SIMPLEX, font_scale, (0, 255, 255), thickness)
                y_offset -= 20
            
            if vis_config['show_match_reason']:
                text = f"{status}"
                cv2.putText(overlay, text, (x1, y_offset),
                           cv2.FONT_HERSHEY_SIMPLEX, font_scale * 0.8, color, thickness)
                y_offset -= 20
            
            if vis_config['show_confidence_score'] and confidence > 0:
                text = f"{confidence:.2f}"
                cv2.putText(overlay, text, (x1, y_offset),
                           cv2.FONT_HERSHEY_SIMPLEX, font_scale * 0.7, (255, 255, 255), thickness)
        
        # Add camera info
        cam_text = f"Camera {camera_id}"
        cv2.putText(overlay, cam_text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        
        return overlay
    
    def _create_mosaic(self, frames: Dict[int, np.ndarray]) -> np.ndarray:
        """Create mosaic view of all cameras"""
        if not self.config['visualization']['mosaic']['enabled']:
            return None
        
        layout = self.config['visualization']['mosaic']['layout']
        cell_w = self.config['visualization']['mosaic']['cell_width']
        cell_h = self.config['visualization']['mosaic']['cell_height']
        
        # Parse layout
        if layout == "2x2":
            rows, cols = 2, 2
        elif layout == "1x2":
            rows, cols = 1, 2
        elif layout == "1x3":
            rows, cols = 1, 3
        elif layout == "1x4":
            rows, cols = 1, 4
        else:
            rows, cols = 2, 2
        
        # Create mosaic canvas
        mosaic = np.zeros((rows * cell_h, cols * cell_w, 3), dtype=np.uint8)
        
        # Fill cells
        sorted_cams = sorted(frames.keys())
        for idx, cam_id in enumerate(sorted_cams):
            if idx >= rows * cols:
                break
            
            row = idx // cols
            col = idx % cols
            
            frame = frames[cam_id]
            # Resize to cell size
            frame_resized = cv2.resize(frame, (cell_w, cell_h))
            
            # Place in mosaic
            y1 = row * cell_h
            y2 = y1 + cell_h
            x1 = col * cell_w
            x2 = x1 + cell_w
            
            mosaic[y1:y2, x1:x2] = frame_resized
        
        return mosaic
    
    def run(self):
        """Main processing loop"""
        logger.info("=" * 60)
        logger.info("HAVEN Multi-Camera ReID System")
        logger.info("=" * 60)
        logger.info(f"Master cameras: {self.config['master_cameras']['ids']}")
        logger.info(f"Total cameras: {len(self.streams)}")
        logger.info("=" * 60)
        logger.info("")
        logger.info("🚀 Starting multi-camera processing...")
        logger.info("Press 'Q' to quit, 'P' to pause")
        logger.info("")
        
        frame_idx = 0
        paused = False
        
        try:
            while True:
                # Check if all streams are still alive
                alive_streams = [s for s in self.streams.values() if s.is_opened()]
                if not alive_streams:
                    logger.info("All streams ended.")
                    break
                
                # Read frames from all cameras
                frames = {}
                overlays = {}
                
                for cam_id, stream in self.streams.items():
                    ret, frame = stream.read()
                    
                    if not ret:
                        logger.debug(f"[cam{cam_id}] End of stream")
                        continue
                    
                    frames[cam_id] = frame
                    
                    # TODO: Run detection + tracking here
                    # For now, just show frames
                    detections = []  # Placeholder
                    
                    # TODO: Assign global IDs
                    # For now, just draw empty overlay
                    overlay = self._draw_overlay(frame, detections, cam_id)
                    overlays[cam_id] = overlay
                    
                    # Write video if enabled
                    if self.config['output']['write_video']:
                        if cam_id not in self.video_writers:
                            h, w = frame.shape[:2]
                            fps = stream.get_fps()
                            self.video_writers[cam_id] = self._create_video_writer(
                                cam_id, w, h, fps
                            )
                        
                        if self.video_writers[cam_id]:
                            self.video_writers[cam_id].write(overlay)
                
                # Create mosaic view
                if overlays:
                    mosaic = self._create_mosaic(overlays)
                    
                    if mosaic is not None:
                        cv2.imshow("HAVEN Multi-Camera", mosaic)
                
                # Handle keyboard
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q') or key == ord('Q'):
                    logger.info("Quit requested")
                    break
                elif key == ord('p') or key == ord('P'):
                    paused = not paused
                    if paused:
                        logger.info("⏸️  PAUSED")
                    else:
                        logger.info("▶️  RESUMED")
                
                while paused:
                    key = cv2.waitKey(100) & 0xFF
                    if key == ord('p') or key == ord('P'):
                        paused = False
                        logger.info("▶️  RESUMED")
                        break
                    elif key == ord('q') or key == ord('Q'):
                        logger.info("Quit requested")
                        return
                
                frame_idx += 1
                
                # Progress update every 100 frames
                if frame_idx % 100 == 0:
                    logger.info(f"Processed {frame_idx} frames...")
        
        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        
        finally:
            self._cleanup()
    
    def _cleanup(self):
        """Cleanup resources"""
        logger.info("\n")
        logger.info("Cleaning up...")
        
        # Release video streams
        for cam_id, stream in self.streams.items():
            stream.release()
            logger.info(f"✅ Released cam{cam_id}")
        
        # Release video writers
        for cam_id, writer in self.video_writers.items():
            if writer:
                writer.release()
                logger.info(f"✅ Closed output for cam{cam_id}")
        
        # Close windows
        cv2.destroyAllWindows()
        
        # Print metrics
        if self.global_id_manager:
            logger.info("\n")
            self.global_id_manager.print_metrics()
        
        logger.info("\n✅ Cleanup complete")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="HAVEN Multi-Camera Person Re-Identification System"
    )
    parser.add_argument(
        '--config',
        type=str,
        default='configs/multicam.yaml',
        help='Path to config YAML file'
    )
    parser.add_argument(
        '--data_root',
        type=str,
        default=None,
        help='Override data_root from config'
    )
    parser.add_argument(
        '--out_dir',
        type=str,
        default=None,
        help='Override output directory'
    )
    parser.add_argument(
        '--no_preview',
        action='store_true',
        help='Disable video preview'
    )
    parser.add_argument(
        '--write_video',
        action='store_true',
        help='Enable video output writing'
    )
    
    args = parser.parse_args()
    
    # Create and run system
    system = MultiCameraReIDSystem(args.config)
    
    # Apply overrides
    if args.data_root:
        system.config['data']['data_root'] = args.data_root
        logger.info(f"Override data_root: {args.data_root}")
    
    if args.out_dir:
        system.config['output']['out_dir'] = args.out_dir
        logger.info(f"Override out_dir: {args.out_dir}")
    
    if args.no_preview:
        system.config['visualization']['enabled'] = False
        logger.info("Preview disabled")
    
    if args.write_video:
        system.config['output']['write_video'] = True
        logger.info("Video output enabled")
    
    # Run
    system.run()


if __name__ == '__main__':
    main()
