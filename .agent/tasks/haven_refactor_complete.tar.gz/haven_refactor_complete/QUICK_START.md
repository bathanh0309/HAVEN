# HAVEN Multi-Camera ReID - Quick Start

## 🚀 CHẠY NGAY (3 BƯỚC)

### Bước 1: Copy Files

Copy toàn bộ nội dung từ `haven_refactor/` vào repo HAVEN của bạn:

```
HAVEN/
├── configs/multicam.yaml              ← COPY
├── backend/src/
│   ├── io/video_stream.py             ← COPY
│   ├── global_id/manager.py           ← COPY
│   └── run_multicam_reid.py           ← COPY
├── tests/test_global_id_manager.py    ← COPY
├── run_multicam.bat                   ← COPY
└── README_IMPLEMENTATION.md           ← COPY
```

### Bước 2: Configure

Edit `configs/multicam.yaml`:

```yaml
data:
  data_root: "D:/HAVEN/backend/data/multi-camera"  # Đường dẫn đến videos
  
master_cameras:
  ids: [1, 2]  # Cam1 và Cam2 là MASTER
```

### Bước 3: Run!

```bash
cd D:\HAVEN
run_multicam.bat
```

Hoặc:

```bash
python backend\src\run_multicam_reid.py --config configs\multicam.yaml
```

---

## ✅ EXPECTED OUTPUT

### Console

```
============================================================
HAVEN Multi-Camera ReID System
============================================================
Master cameras: [1, 2]
Total cameras: 4
============================================================

🚀 Starting multi-camera processing...

🆕 [cam1] Track 1 → Global ID 1 (MASTER_NEW: empty_gallery)
✅ [cam2] Track 3 → Global ID 1 (MATCHED: score=0.82)
🆕 [cam2] Track 5 → Global ID 2 (MASTER_NEW: low_similarity=0.45)
⏳ [cam3] Track 2 → TEMP (non-master, wait for master)
✅ [cam3] Track 2 → Global ID 1 (MATCHED: score=0.78)
```

### Video Outputs

```
D:/HAVEN/backend/outputs/multicam/
├── cam1_output.mp4
├── cam2_output.mp4
├── cam3_output.mp4
├── cam4_output.mp4
└── mosaic_output.mp4  (2x2 grid)
```

---

## 🔑 KEY POINTS

### Dual-Master Logic (3 Bullets)

1. **Cam1 và Cam2 = MASTER** có quyền tạo Global ID mới
   - Khi thấy người mới (không match) → tạo ID mới (1, 2, 3, ...)

2. **Cam3 và Cam4 = NON-MASTER** chỉ có thể MATCH
   - Khi thấy người mới → gán TEMP ID = 0, đợi master camera

3. **Gallery được share toàn bộ**
   - Cam2 tạo ID → Cam1 thấy được
   - Cam1 tạo ID → Cam2 thấy được
   - → Không bao giờ duplicate IDs

### Flow Example

```
Scenario: Người đi xe máy vào thẳng Cam2

t=0s  : Cam2 (MASTER) thấy person A
        → So sánh gallery (rỗng)
        → Tạo Global ID = 1 ✅

t=10s : Cam1 (MASTER) thấy person A
        → So sánh gallery [ID=1 by Cam2]
        → Similarity = 0.82 > 0.75
        → MATCH → Global ID = 1 ✅ (không tạo mới!)

t=20s : Cam3 (NON-MASTER) thấy person A
        → So sánh gallery [ID=1]
        → Similarity = 0.78 > 0.75
        → MATCH → Global ID = 1 ✅

t=30s : Cam3 (NON-MASTER) thấy person B (mới)
        → So sánh gallery [ID=1]
        → Similarity = 0.40 < 0.50
        → Cam3 KHÔNG CÓ QUYỀN tạo ID
        → Gán TEMP ID = 0 ⏳

t=40s : Cam1 (MASTER) thấy person B
        → So sánh gallery [ID=1]
        → Similarity = 0.42 < 0.50
        → Cam1 tạo Global ID = 2 ✅

t=50s : Cam3 (NON-MASTER) thấy lại person B
        → So sánh gallery [ID=1, ID=2]
        → Similarity với ID=2 = 0.80 > 0.75
        → MATCH → Global ID = 2 ✅
```

---

## ⚙️ TUNING

### Too Many False Matches?
```yaml
reid:
  thresholds:
    accept: 0.80  # Tăng từ 0.75
```

### Too Many ID Switches?
```yaml
reid:
  thresholds:
    accept: 0.70  # Giảm từ 0.75
```

---

## 📖 FULL DOCS

- **README_IMPLEMENTATION.md**: Chi tiết implementation
- **REFACTOR_PLAN.md**: Architecture & integration guide
- **configs/multicam.yaml**: All settings with comments

---

## ❓ FAQ

**Q: Làm sao để Cam3 cũng thành master?**
```yaml
master_cameras:
  ids: [1, 2, 3]
```

**Q: Có thể chỉ có 1 master không?**
```yaml
master_cameras:
  ids: [1]  # Only Cam1
```

**Q: Có thể tất cả đều là master không?**
```yaml
master_cameras:
  ids: [1, 2, 3, 4]  # All are masters
```

**Note**: Nếu tất cả đều là master, sẽ không có TEMP IDs.

---

**Ready to run! 🚀**
